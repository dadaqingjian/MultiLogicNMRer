"""
针对非单调推理的神经符号方法的实现
"""
import copy
import random
import sys
import re
import httpx
import requests
import torch
sys.path.append('../../Dataset')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
Reasoning_Mode = 'skeptical' # [credulous, skeptical]
Credulous_Skeptical_Flag = 'Skeptical'
Dataset_Category = 'test' # ['train', 'dev', 'test']
Zero_or_Few_Shot = 'Zero_Shot' # ['Zero_Shot','Few_Shot']
OOD_Flag = False
OOD_Data_Path = "OOD_Datasets" if OOD_Flag == True else ''
OOD_read_filename = "_OOD" if OOD_Flag == True else ''
OOD_write_filename = "OOD_" if OOD_Flag == True else ''
read_file_path = None
LLMs_Generate = True
LLMs_Generate_Datasets = 'GPT4_LLMs_Generated_' if LLMs_Generate == True else ''
if OOD_Flag == True:
    read_file_path = './../../Automated_Construct_MultiNMR/Datasets/' + OOD_Data_Path + '/'

read_file_path = './../../Automated_Construct_MultiNMR/LLMs_Generate_Datasets/' + Reasoning_Mode + '/' if LLMs_Generate == True else './../../Automated_Construct_MultiNMR/Datasets/' + Reasoning_Mode + '/'

write_file_path = './../../Automated_Construct_MultiNMR/Experimens/LLMs_Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 #用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6,16
LLMs_Models_Choise = "GPT3.5" #['GPT3.5','GPT4','Claude','Gemma_7B','Mistral_7B']
Read_Data_file = read_file_path + LLMs_Generate_Datasets + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + OOD_read_filename + '_all_at_once3.json'
Write_file_path02 = write_file_path + 'Iterative_NeSy_'+ Zero_or_Few_Shot +'_'+ LLMs_Models_Choise + '_result_on_' + OOD_write_filename + LLMs_Generate_Datasets + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '_all_at_once3.json'
import warnings

warnings.filterwarnings("ignore")
bnb_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_use_double_quant=True, bnb_4bit_quant_type="nf4",bnb_4bit_compute_dtype=torch.bfloat16)

# import spacy
# nlp = spacy.load('en_core_web_trf')  # 引用小的英语指代模型
# nlp.add_pipe('coreferee')
import numpy as np
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


# 设置随机数种子
setup_seed(20)

Label_Dict = {'F':[0],'T':[1],'M':[2]}

# 提示用于获取实例化规则中的结论。
Grounded_Prompt_Instrunction = 'Task Description: \n Given a set of facts and a rule, you need to instantiate the rules based on given facts. Instantiation requires the replacement of pronouns in rules with individuals from the fact.   \n For example 1: The input facts are: Toby is not loud. Toby lacks intelligence. Toby is attractive. Toby is not vigilant. Toby is truthful. Toby is significant. \n  The input rule is: If an individual is attractive yet unwise, they are considered delectable, unless they are dull. \n The output is: If Toby is attractive yet unwise, Toby are considered delectable, unless Toby are dull. \n Note that you need to output all instantiation rules. The output format is: The output is:''.'

# 通过提示获取规则中的所有原子
All_Atomes_Prompt_Instruction = "Task Description: \n  Given a rule， you need to extract all instantiated facts in the rule. \n  For example 1: The input rule is: If Toby is attractive yet unwise, Toby are considered delectable, unless Toby are dull.  \n The output is: Toby is attractive.  Toby is unwise. Toby are considered delectable. Toby are dull.  \n  For example 2: The input rule is: If Toby is delectable but not vigilant, Toby are considered sizable, unless Toby mourn or are not mean-spirited. \n The output is: Toby is delectable. Toby is not vigilant. Toby are considered sizable. Toby is mourn. Toby are not mean-spirited.\n Note that you only need to output all instantiated facts in the rule, do not print the contents of the prompt, and don't output the same facts repeatedly. The output format is: The output is:''."
# 对规则进行约间的提示
Iterative_Reduction_Prompt = "Task Description: \n  Given facts and rules, The rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is the justification.  If the prerequisite A of the rule is in the fact and the justification C is not in facts , then the output is 'If A then B'; If the justification C of the rule is in fact, then the output is: inconsistent;  \n For example 1: Facts are: Godwin is not sour. Godwin is short. Godwin is scared. Godwin is wild. Godwin is expensive. Godwin is not bad. Godwin is not straightforward. Godwin is anxious. Godwin is not stubborn. Godwin is not zany. Godwin laugh Connor. Godwin esteem Connor. Godwin is not poor. Godwin is persistent. The rule is: If Godwin laugh Connor and Godwin is not stubborn then Godwin is old, unless Godwin is not poor or Godwin is happy.  \n The output is: inconsistent. \n  For example 2: Facts are: Cara is loving. Cara is not straightforward. Cara is fearless. Cara is not zany. Cara is not combative. Cara is several. Cara is hollow. Cara is emotional. Cara is poor. Cara is granite. Cara does not laugh Lewis. Cara is not southern. Cara is not cheap. The rule is: If Cara is poor and emotional then Cara is able, unless Cara is dry or Cara is not supportive. \n  The output is: If Cara is poor and emotional then Cara is able. \n  The output format is: The output is:''."

Iterative_Split_Rule_Prompt = "Task Description:  \n Given a rule, The rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is the justification.  You need to output all prerequisite, conclusions, and justifications in this rule. The output format is: The output is: prerequisite:'', conclusion:'', justification:''.  \n For example 1: The rule is: If Toby is attractive yet unwise, Toby is considered delectable, unless Toby is dull.  \n  The output is: prerequisite: 'Toby is attractive. Toby is unwise. ', conclusion:'Toby is considered delectable. '.  justification:'Toby is dull. '. \n  For example 2: The rule is: If Toby is unique, Toby is not plentiful, unless Toby is not bewildered or Toby is economically stable. \n  The output is: prerequisite:' Toby is unique.'. conclusion:'Toby is not plentiful '; justification:' Toby is not bewildered. Toby is economically stable. '.  \n  The output format is: The output is:''."

# 封闭蕴含推理，即在给定事实列表和规则条件下，当给出的事实列表能够满足前提条件，同时也满足一致性条件时，就可以得出结论事实
Iterative_Conclusion_Reasoning_Prompt = "Task Description: \n  Given facts and a rule. You need to reason about the rules based on facts. The rule format is usually: If A then B. The A is the prerequisite, the B is the conclusion. If the prerequisite A is in the facts, you can deduce conclusion B. If the prerequisite A is not in the facts, then you can not deduce the conclusion B, so your output is: None. \n  Example 1: The input facts are: Toby is not loud. Toby lacks intelligence. Toby is attractive.  Toby is not vigilant. Toby is truthful. Toby is significant.  Toby is youthful. Toby is not gloomy. Toby shows disdain towards Benjamin. Toby is fervent. Toby is not stunning. Toby is frightened. The rules are: If  Toby is attractive and  Toby is unwise then  Toby is considered delectable. \n The output is: Toby is considered delectable. \n  For example 2: The facts are: Toby is not loud. Toby lacks intelligence. Toby is attractive. Toby is not vigilant. Toby is truthful.  Toby is significant. Toby is youthful. Toby is not gloomy. Toby shows disdain towards Benjamin. Toby is fervent. Toby is not stunning. Toby is frightened. Toby is considered sizable. The rule is: If  Toby is quiet and Toby is delectable then Toby is termed unique.  \n The output is: None. \n Note that you only need to output rule conclusions that can be inferred, not facts and reasoning processes. The output format is: The output is:''."

# 选择下一个事实模块的提示
Choose_fact_Prompt = "Task Description: \n Given fact set 1, fact set 2 and a question list, you need to generate a fact that is in fact set 2 but not in fact set 1, and at the same time, the generated fact is required to be closest to the question. If all facts in fact set 2 appear in fact set 1, then your output is: None. \n  For example 1: The facts set 1 are: Orson and Leroy is misjudge. Orson is hot. Orson and Leroy is laugh. Orson is emotional. Orson is amused. Orson is jolly. Orson and Leroy is honour. The facts set 2 are: Orson is amused. Orson is jolly. Orson and Leroy is honour.Orson is attractive. Orson is giant. Orson is melodic. Orson and Leroy is like. Questions are: Orson is happy. Orson is not attractive. Orson is attractive. \n  The output is: Orson is attractive. \n  For example 2: The facts set 1 are: Kirby is cool. Kirby is cloudy. Kirby is hurt. Kirby is nice. Kirby is sensible. Kirby is lively. Kirby is sweet. The facts set 2 are: Kirby is cool. Kirby is cloudy. Kirby is lively. Kirby is sweet. Kirby is hurt. Kirby is nice. Kirby is sensible. Questions are: Kirby is   nice. Kirby is not nice.  \n The output is: None.  \n The output format is: The output is:''."

# 基于大语言模型生成否定问题

# 在谨慎推理模式下的提示
Credulous_Reasoning_Prompt = 'Dask Description:  \n you need to generate answer labels for questions according to the all facts set. The answers to the questions are labeled "True", "False" and "Unknown". If the question can be inferred based on a certain facts set, the answer label of the question is "True"; if the negation of the question can be inferred based on a certain facts set, the answer label of the question is "False"; If the question and the negation of the question both cannot be deduced under all facts set, the answer label of the question is "Unknown". The input format is The facts set 1 are: ". The facts set 2 are:''. \n  The question is:".  \n The output format is: The output is:".  \n For example: The facts set 1 are: Magnus and Malcolm is spurn. Magnus is difficult. Magnus is arrogant. Magnus is nasty. Magnus is dangerous. Magnus is important. Magnus is vast. Magnus is dramatic. Magnus is handsome. The facts set 2 are: Magnus is important. Magnus is vast. Magnus is dramatic. Magnus is handsome. Magnus is poor. Magnus is sensitive. The question is: Magnus is  important. The output is: True.  \n For example 2: The facts set 1 are: Ramon is grieving.Ramon is clean. Ramon is actual. Ramon is envious. Ramon is colorful. Ramon is muddy. Ramon is capable. Ramon is unlikely. Ramon is doubtful. The facts set 2 are: Ramon is actual. Ramon is envious. Ramon is colorful. Ramon is muddy. Ramon is capable. Ramon is unlikely. Ramon is doubtful.  \n The question is: Romon is distinct.  \n The output is: Unknown.  \n For example 3: The facts 1 are: Daisy is lonely.Daisy is not distinct. Daisy is dead. Daisy is dull. Daisy is cheerful. Daisy and Axel is sneer. Daisy is dangerous. Daisy is obvious. Daisy is responsible. The facts 2 are: Daisy is cheerful. Daisy and Axel is sneer. Daisy is not dangerous. Daisy is obvious. Daisy is responsible.  \n The question is: Daisy is responsible.  \n The output is: False. \n  Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read all facts set carefully and answer the question. '
# 可怀疑推理模式，让大模型基于可怀疑推理模式的打标签方式进行推理
Skeptical_Reasoning_Prompt = 'Dask Description: \n  you need to generate answer labels for questions in a given all facts set. The answers to the questions are labeled "True", "False" and "Unknown". If the question can be inferred under all reasoning paths based on the all facts set, and the negation of the question cannot be inferred based on the all facts set, the answer label of the question is "True"; if the negation of the question can be inferred based on the all facts set, and the question cannot be inferred based on the all facts set, the answer label of the question is "False"; If the question and the negation of the question cannot be deduced based on a certain fact set, the answer label of the question is "Unknown",.  The input format is: The facts are:''. The rules are:''. The reasoning path 1 are:". The reasoning path 2 are:''. The question is:".  \n You must generate answer labels for the question. The output format is: The output is:".  \n For example: The facts are: Luther is crowded.Luther is teak.Luther is persistent.Luther is not amused.Luther is not educational.Luther is not putrid.Luther is not attractive.Luther is not jolly.Luther is different.Luther is not able.Luther is long.Luther and Iver is not like. The rules are: If someoneA not like someoneB and someoneA is crowded then he is beautiful ,unless he is not beautiful.If someoneA is not amused and not beautiful then he is frank,unless he is decent or he is not educational.The  Different people are usually octagonal.If someoneA is not putrid then he is not frank,unless he is fair or he is frank.If someoneA is not educational and not attractive then he is not octagonal,unless he is wonderful or he is octagonal.The  Octagonal people are usually jittery.If someoneA is not jolly and persistent then he is not jittery,unless he is jittery or he is poor.If someoneA is long then he is several ,unless he is giant.If someoneA is not able and teak then he is shiny,unless he is jolly or he is not southern.The  Shiny people are usually not several. The reasoning path 1 are: Luther is several.Luther is jittery.Luther is beautiful.Luther is not frank.The reasoning path 2 are: Luther is several.Luther is beautiful.Luther is not jittery.Luther is not frank. The reasoning path 3 are: Luther is several.Luther is beautiful.Luther is not jittery.Luther is not octagonal.Luther is not frank. The question is: Luther is beautiful. The output is: True. The question is: Luther is frank. The output is: False. The question is:Luther is not octagonal.The output is: Unknown. Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read all facts set carefully and answer the question. '

Yeliang_API_Key = "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b" # "sk-wYnDOGnqs7X62a2DEcFa8094B6384f2aAf12AfD88d1dC649", "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b"
Base_URL =  "https://35.aigcbest.top/v1" #  "https://api.nhyun.top" #"https://35.aigcbest.top/v1"
Answer_Set_List = []
Soft_Answer_Set_List =[] # 存储下界大于上界时的回答集，如果严格条件下求出的答案集为空，则将松弛条件下的答案集作为最终答案集
Prerequisite_Conclusion_Consistent_Facts_Dict ={} # 用于存储每个样本的
Each_Example_chatgpt_Number = 0 # 用于记录每个样本调用大模型的次数
Slove_Iternumber = 3 # 用于指示搜索迭代的深度
llama3_8B_model, llama3_model_tokenizer = None, None
if LLMs_Models_Choise == 'LLAMA3_8B_Instruct':
    llama3_8B_model = AutoModelForCausalLM.from_pretrained("/home/yeliangxiu/Projects/Pre_trained_Models/Meta-Llama-3-8B-Instruct", quantization_config=bnb_config, device_map="cuda")
    llama3_model_tokenizer = AutoTokenizer.from_pretrained("/home/yeliangxiu/Projects/Pre_trained_Models/Meta-Llama-3-8B-Instruct")
    llama3_model_tokenizer.pad_token = llama3_model_tokenizer.eos_token
    llama3_model_tokenizer.padding_side = "right"

def chatGPT_Solver(instructions, context):
    global Each_Example_chatgpt_Number
    Each_Example_chatgpt_Number = Each_Example_chatgpt_Number + 1
    print('Each_Example_chatgpt_Number={}'.format(Each_Example_chatgpt_Number))
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key)
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="gpt-3.5-turbo", # gpt-3.5-turbo/ gpt-4-turbo-preview
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context }
                ],
                temperature=0,
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
    return ""

def LLAMA3_generate_text(Instruction, Context_Text_String):
    Test_prompt = f"""###Instruction:{Instruction}\n###Context: {Context_Text_String}\n### Response:"""
    input_ids = llama3_model_tokenizer(Test_prompt, return_tensors="pt").input_ids.cuda()
    outputs = llama3_8B_model.generate(input_ids=input_ids, max_new_tokens=100, pad_token_id=llama3_model_tokenizer.eos_token_id, do_sample=True, top_p=0.9, temperature=0.1) # max_new_tokens=100,
    generated_ids = [output_ids[len(input_ids):] for input_ids, output_ids in zip(input_ids, outputs)]
    # Decode the response
    LLAMA3_LLMs_response_output = llama3_model_tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
    return LLAMA3_LLMs_response_output

Iterative_Base_Model = None
Output_Pattern = None
if LLMs_Models_Choise =='LLAMA3_8B_Instruct':
    Iterative_Base_Model = LLAMA3_generate_text
    Output_Pattern = "(?<=output is:).*?(?=Note|#|Instruction|1```1)"  # 用于提取LLAMA3的输出结果
    Output_Grounded_Pattern = "(?<=output is:).*?(?=Note|#|Instruction|Instantiation|\.|1```1|Instantiated)"  # 用于提取LLAMA3的输出结果
    Reasoning_Output_Pattern = "(?<=output is:).*?(?=Note|#|Instruction|1```1|Final Answer|\.)"  # 用于提取LLAMA3的输出结果 # Final Answer:

elif LLMs_Models_Choise =='GPT3.5':
    Iterative_Base_Model = chatGPT_Solver
    Output_Pattern = "(?<=output is:).*?(?=Note|#|Instruction|1```1|(.*))"  # 用于提取LLAMA3的输出结果
    Output_Grounded_Pattern = "(?<=output is:).*?(?=Note|#|Instruction|Instantiation|\.|1```1|Instantiated)"  # 用于提取LLAMA3的输出结果
    Reasoning_Output_Pattern = "(?<=output is:).*?(?=Note|#|Instruction|1```1|Final Answer|\.)"  # 用于提取LLAMA3的输出结果 # Final Answer:

import difflib

from sentence_transformers import SentenceTransformer, util
Similarity_Value = 0.95
# 创建模型，这里使用了distilbert-base-nli-stsb-mean-tokens模型
sentence_transformersmodel = SentenceTransformer('distilbert-base-nli-stsb-mean-tokens')
# 基于Sentence_Transformers的相似性计算
def similarity(str1, str2):
    # 将句子转换为向量表示
    sentence1_embedding = sentence_transformersmodel.encode(str1)
    sentence2_embedding = sentence_transformersmodel.encode(str2)
    # 计算句子之间的相似度
    cosine_similarity = util.cos_sim(sentence1_embedding, sentence2_embedding)
    return cosine_similarity

# 定义事实集合的等价性判断函数
def equation(fact_list01, fact_list02):
    # 遍历集合1中的事实
    fact_list_similarity01, fact_list_similarity02 = "True", "True"

    fact_similarity = similarity(fact_list01, fact_list02)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1) # 求相似矩阵中的每一行的最大值
    min_max_fact_similarity01 = torch.min(max_fact_similarity01.values)
    if min_max_fact_similarity01 < Similarity_Value:
        fact_list_similarity01 = "False"

    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity02 = torch.max(fact_similarity, dim=0)  # 求相似矩阵中的每一列的最大值
    min_max_fact_similarity02 = torch.min(max_fact_similarity02.values)
    if min_max_fact_similarity02 < Similarity_Value:
        fact_list_similarity02 = "False"

    if fact_list_similarity01 == "True" and fact_list_similarity02 == "True":
        return "True"
    else:
        return "False"


# 定义一个函数，用于判断事实1是否包含在事实列表2中
def Include(fact_list01, fact_list02):
    # 遍历集合1中的事实
    fact_list_similarity01 = "True"
    fact_similarity = similarity(fact_list01, fact_list02)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    min_max_fact_similarity = torch.min(max_fact_similarity01.values)
    # 同时计算出事实1集合中存在不包含在事实集合2 中的事实数量
    different_fact_number = 0
    if min_max_fact_similarity < Similarity_Value:
        different_fact_number = different_fact_number + 1

        fact_list_similarity01 = "False"

    return fact_list_similarity01, different_fact_number

# 定义一个函数，用于求二个事实集合的并
def fact_union(fact_list01, fact_list02):
    fact_union_list = copy.deepcopy(fact_list02)
    fact_similarity = similarity(fact_list01, fact_list02)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    # 如果事实1集合中的事实与事实2集合中的事实相似性小于0.9, 则将事实1添加到事实2中
    for key01 in range(len(fact_list01)):
        if max_fact_similarity01.values[key01] < Similarity_Value:
            fact_union_list.append(fact_list01[key01])

    return fact_union_list

# 定义一个函数，用于求二个事实集合的交
def fact_intersection(fact_list01, fact_list02):
    fact_intersection = []
    fact_similarity = similarity(fact_list01, fact_list02)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    # 如果事实1集合中的事实与事实2集合中的事实相似性小于0.9, 则将事实1添加到事实2中
    for key01 in range(len(fact_list01)):
        if max_fact_similarity01.values[key01] > Similarity_Value: # 最大相似度大于0.9， 则说明二个集合中都包含相同的事实
            fact_intersection.append(fact_list01[key01])

    return fact_intersection


# 定义一个函数用于对事实列表进行去重
def Remove_Same_Fact(fact_list01):
    remain_fact_list = []
    for key01 in range(len(fact_list01)):
        if len(fact_list01[key01])<10:
            continue
        fact01 = fact_list01[key01]
        if key01 ==0:
            remain_fact_list.append(fact01)
        else:
            # 需要判断fact01是否在remain_fact_list列表中
            fact_similarity = similarity(fact01, remain_fact_list)
            # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
            max_similarity = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
            if max_similarity.values[0] < Similarity_Value:
                remain_fact_list.append(fact01)
    return remain_fact_list


# 定义一个函数，用于从事实列表中删除一个事实
def Remove(fact, fact_list01):
    # 找到相似度最大匹配的那个事实进行删除
    Remove_List = []

    fact_similarity = similarity(fact, fact_list01)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    for fact_key in range(len(fact_list01)):
        if fact_similarity[0][fact_key] < max_fact_similarity01.values[0]:
            Remove_List.append(fact_list01[fact_key])
    return Remove_List

# 定义一个函数，用于从事实2中删除事实1中的事实
def Remove_Fact(fact_list01, Answer_Set_Facts):
    # 找到相似度最大匹配的那个事实进行删除
    Remain_List = []

    fact_similarity = similarity(Answer_Set_Facts, fact_list01)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    for fact_key in range(len(Answer_Set_Facts)):
        if max_fact_similarity01.values[0] < Similarity_Value:
            Remain_List.append(Answer_Set_Facts[fact_key])
    return Remain_List

# 定义一个函数，用于调用工具继续实例化 基于Spacy的进行指代消解
def Grounded_Reasoning_based_Coref_Model(Origin_Facts, Origin_Question_Text):
    result_fact = ''
    # 处理文本
    doc = nlp(fact01)

    coref_result_dict = doc._.coref_chains

    for dict_key in coref_result_dict.keys():
        coref_list = coref_result_dict[dict_key]
        # 找出实体
        entity = ''
        for key01 in range(len(coref_list)):
            if coref_list[key01] not in ['he','him','she','someoneA','someoneB','someone']:
                entity = coref_list[key01]
        # 替换
        for key02 in range(len(coref_list)):
            doc[coref_list[key02]] = entity
    return result_fact

# 定义一个函数，用于调用大模型进行实例化
def Grounded_Reasoning_based_LLMs(NL_Origin_Facts, Total_Rule_Strings,rule_key01 ):
    global Output_Grounded_Pattern
    grounded_rule_result = ''
    while_count01 = 0
    while True:
        # 调用大模型对每个规则进行实例化，
        if while_count01 >=10:
            break
        gounded_rule_context = 'The input facts are: ' + NL_Origin_Facts + 'The input rule are:' + Total_Rule_Strings
        grounded_rule_result = Iterative_Base_Model(Grounded_Prompt_Instrunction, gounded_rule_context)
        print("利用大模型实例化上下文：rule_key01={}, \n grounded_rule_result={},\n gounded_rule_context={}".format(rule_key01, grounded_rule_result,gounded_rule_context))
        grounded_rule_result = grounded_rule_result.replace('\n', '')
        grounded_rule_result = grounded_rule_result[:200]
        while_count01 = while_count01 + 1
        if grounded_rule_result[:20].find('output is') == False or grounded_rule_result[:20].find('output is') == -1:
            grounded_rule_result = ' The output is: ' + grounded_rule_result
        grounded_rule_string = ''
        grounded_rule_result = grounded_rule_result.replace('\n', '')
        if ':' in grounded_rule_result and 'output' in grounded_rule_result:
            grounded_rule = re.findall(Output_Grounded_Pattern, grounded_rule_result)
            if len(grounded_rule) == 0:
                continue
            grounded_rule_string = grounded_rule[-1]
            if len(grounded_rule_string) < 5:
                continue
            else:
                grounded_rule_list = grounded_rule_string.split('.')
                if len(grounded_rule_list) < 1:
                    continue
                for key in range(len(grounded_rule_list)):
                    if len(grounded_rule_list[key]) < 5:
                        continue
                    else:
                        grounded_rule = grounded_rule_list[key]
                        grounded_rule_result = grounded_rule
                break
        else:
            continue
    if while_count01>=10:
        grounded_rule_result = Total_Rule_Strings
    return grounded_rule_result

# 定义一个函数，用于根据大模型对规划划分后的前提条件、一致性条件和结论进行约简
# 输入为事实列表和上下文
# 约简规则：只要事实中出现在一致性条件中的事实出现在事实中，就不能进行约简
def Iterative_Split_Reduction_Prompt_Based_Similarity(TA_facts_list, FA_facts_list, TA_conclusion, FA_conclusion, context, rule_number):
    TA_Reduction_Result, FA_Reduction_Result = '', ''
    TA_facts_list02, FA_facts_list02 = copy.deepcopy(TA_facts_list), copy.deepcopy(FA_facts_list)
    # 在迭代遍历规则进行约简和推理时，需要将之前规则推出的结论对上下界进行更新
    if 'None' not in TA_conclusion and TA_conclusion not in TA_facts_list02:
        TA_facts_list02.append(TA_conclusion)
    if 'None' not in FA_conclusion and FA_conclusion not in FA_facts_list02:
        FA_facts_list02.append(FA_conclusion)
    # 调用大模型对规则进行划分，分别产生前提条件、一致性条件和结论事实列表
    global Prerequisite_Conclusion_Consistent_Facts_Dict
    prerequisites_list, consistencys_list, conclusions_list = [], [], []
    if rule_number not in Prerequisite_Conclusion_Consistent_Facts_Dict.keys():
        Prerequisite_Conclusion_Consistent_Facts_Dict[
            rule_number] = {}  # 用于存储每个样本的每个规则的前提条件、一致性条件和结论，关键字为前提条件、一致性条件和结论，值为对应的事实列表
        while_count01 = 0
        while True:
            if while_count01 > 10:
                break
            prerequisites_list, consistencys_list, conclusions_list = [], [], []
            Iterative_Split_Rule_Result = Iterative_Base_Model(Iterative_Split_Rule_Prompt, context)
            if Iterative_Split_Rule_Result.find('output is') == -1:
                Iterative_Split_Rule_Result = 'The output is:' + Iterative_Split_Rule_Result
            Iterative_Split_Rule_Result = Iterative_Split_Rule_Result.replace('\n', '')
            while_count01 = while_count01 + 1
            print('Iterative_Split_Rule_Result={}'.format(Iterative_Split_Rule_Result))
            if 'output' in Iterative_Split_Rule_Result and ':' in Iterative_Split_Rule_Result and 'prerequisite' in Iterative_Split_Rule_Result and 'justification' in Iterative_Split_Rule_Result and 'conclusion' in Iterative_Split_Rule_Result:
                prerequisites = re.findall(r".*prerequisite:(.*)conclusion", Iterative_Split_Rule_Result)
                conclusion = re.findall(r".*conclusion:(.*)justification", Iterative_Split_Rule_Result)
                justifications = re.findall(r".*justification:(.*)", Iterative_Split_Rule_Result)

                # 遍历前提条件
                if len(prerequisites) != 0:
                    prerequisites_list01 = prerequisites[0].split('.')
                    for key01 in range(len(prerequisites_list01)):
                        if len(prerequisites_list01[key01]) > 5:
                            prerequisites_list01[key01] = prerequisites_list01[key01].replace('\'', '')
                            prerequisites_list.append(prerequisites_list01[key01])
                # 遍历结论
                if len(conclusion) != 0:
                    conclusion_list01 = conclusion[0].split('.')
                    for key03 in range(len(conclusion_list01)):
                        if len(conclusion_list01[key03]) > 5:
                            conclusion_list01[key03] = conclusion_list01[key03].replace('\'', '')
                            conclusions_list.append(conclusion_list01[key03])
                # 遍历一致性条件
                if len(justifications) != 0:
                    justifications_list01 = justifications[0].split('.')
                    for key02 in range(len(justifications_list01)):
                        if len(justifications_list01[key02]) > 5:
                            justifications_list01[key02] = justifications_list01[key02].replace('\'', '')
                            consistencys_list.append(justifications_list01[key02] + '.')
                else:
                    continue
                break
            else:
                continue

        Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['prerequisites'] = prerequisites_list
        Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['consistencys'] = consistencys_list
        Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['conclusions'] = conclusions_list
        print(
            '大模型产生的约简结果：len(prerequisites)={}, prerequisites:={}, len(conclusion)={}, conclusion={}, len(justifications)={}, justifications={}'.format(
                len(prerequisites_list), prerequisites_list, len(conclusions_list), conclusions_list,
                len(consistencys_list), consistencys_list))

    else:
        prerequisites_list = Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['prerequisites']
        consistencys_list = Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['consistencys']
        conclusions_list = Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['conclusions']
        print(
            '使用存储好的规则约简结果：len(prerequisites)={}, prerequisites:={}, len(conclusion)={}, conclusion={}, len(justifications)={}, justifications={}'.format(
                len(prerequisites_list), prerequisites_list, len(conclusions_list), conclusions_list,
                len(consistencys_list), consistencys_list))

    # 然后根据相似度判断是否需要进行约减
    # 如果前提条件都在事实中，即相似度都大于0.95，且一致性条件都不在事实中，则进行TA事实集合下的约减
    TA_Total_Prerequisite_Flag, TA_Total_Consistency_Flag, TA_Total_Conclusion_Flag = 'False', 'False', 'False'
    TA_Prerequisite_Flag_list, TA_Consistency_Flag_list, TA_Conclusion_Flag_list = [], [], []

    # 遍历一致性条件

    consistency_TA_similarity = similarity(consistencys_list, TA_facts_list02) if len(consistencys_list) > 0 else torch.tensor([[0]])
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_consistency_TA_similarity = torch.max(consistency_TA_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    for key01 in range(len(consistencys_list)):
        if max_consistency_TA_similarity.values[key01] > Similarity_Value:
            TA_Consistency_Flag_list.append('True')
        else:
            TA_Consistency_Flag_list.append('False')
            break

    TA_Total_Consistency_Flag = 'True' if 'True' in TA_Consistency_Flag_list else 'False'
    prerequisites_string = ''
    for key01 in range(len(prerequisites_list)):
        prerequisites_string = prerequisites_list[key01] + ' ' if int(key01) == 0 else prerequisites_string + ' and ' + \
                                                                                       prerequisites_list[key01] + ' '

    # 如果一致性条件出现在事实中，即相似度都大于0.95，且一致性条件都不在事实中，则进行约减
    # 下界约简用于更新上届，只需选择下界约简后规则的结论在上界中是否存在，如果不存在则不需要进行约简 and TA_Total_Conclusion_Flag == 'True'
    if TA_Total_Consistency_Flag == 'False' and len(conclusions_list) > 0:
        TA_Reduction_Result = 'If ' + prerequisites_string + ' then ' + conclusions_list[0] + '. '
    else:
        TA_Reduction_Result = 'Inconsistent'
    # 在FA事实集合下进行约减
    FA_Total_Prerequisite_Flag, FA_Total_Consistency_Flag, FA_Total_Conclusion_Flag = 'False', 'False', 'False'
    FA_Prerequisite_Flag_list, FA_Consistency_Flag_list, FA_Conclusion_Flag_list = [], [], []

    # 遍历一致性条件
    consistency_FA_similarity = similarity(consistencys_list, FA_facts_list02) if len(consistencys_list) > 0 else torch.tensor([[0]])
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_consistency_FA_similarity = torch.max(consistency_FA_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    for key01 in range(len(consistencys_list)):
        if max_consistency_FA_similarity.values[key01] > Similarity_Value:
            FA_Consistency_Flag_list.append('True')
        else:
            FA_Consistency_Flag_list.append('False')
            break

    FA_Total_Consistency_Flag = 'True' if 'True' in FA_Consistency_Flag_list else 'False'
    prerequisites_string = ''
    for key01 in range(len(prerequisites_list)):
        prerequisites_string = prerequisites_list[key01] + ' ' if int(key01) == 0 else prerequisites_string + ' and ' + \
                                                                                       prerequisites_list[key01] + ' '

    # 如果前提条件都在事实中，即相似度都大于0.9，且一致性条件都不在事实中，则进行约减 and FA_Total_Conclusion_Flag=='False'
    if FA_Total_Consistency_Flag == 'False' and len(conclusions_list) > 0:
        FA_Reduction_Result = 'If ' + prerequisites_string + ' then ' + conclusions_list[0] + '. '
    else:
        FA_Reduction_Result = 'Inconsistent'
    TA_conclusion02, FA_conclusion02 = '', ''
    FA_List_String02 = ''
    for key01 in range(len(FA_facts_list02)):
        FA_List_String02 = FA_List_String02 + FA_facts_list02[key01]
    TA_List_String02 = ''
    for key02 in range(len(TA_facts_list02)):
        TA_List_String02 = TA_List_String02 + TA_facts_list02[key02] + ' '
    # 然后迭代的对约间结果进行推理
    # 推理步骤进一步分为二步，第一步进行约间，第二步进行推理Concluson操作推理
    if 'Inconsistent' not in FA_Reduction_Result:
        TA_FA_Flag = 'FA'  # 用于指示是在下界还是上界进行推理
        FA_conclusion02 = Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, FA_List_String02, FA_Reduction_Result,
                                                                rule_number)
    else:
        FA_conclusion02 = 'None'

    if 'Inconsistent' not in TA_Reduction_Result:
        TA_FA_Flag = 'TA'  # 用于指示是在下界还是上界进行推理
        TA_conclusion02 = Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, TA_List_String02, TA_Reduction_Result,
                                                                rule_number)
    else:
        TA_conclusion02 = 'None'

    print(
        'Reduction and Reasoning: rule_number={},FA_Reduction_Result={}, FA_conclusion02={}, TA_Reduction_Result={}, TA_conclusion02={}'.format(
            rule_number, FA_Reduction_Result, FA_conclusion02, TA_Reduction_Result, TA_conclusion02))

    return TA_conclusion02, FA_conclusion02


# 定义一个函数，用于实现对基于大模型的推理
def Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, Facts_String02, Reduction_Rule, rule_number):
    reasoning_result = ''
    while_count02 = 1
    global Reasoning_Output_Pattern
    while True:
        FA_Conclusion_Reasoning_Context = 'The facts are: ' + Facts_String02 + 'The rules are: ' + Reduction_Rule
        FA_conclusion_result = Iterative_Base_Model(Iterative_Conclusion_Reasoning_Prompt,FA_Conclusion_Reasoning_Context)
        FA_conclusion_result = FA_conclusion_result.replace('\n', '')
        FA_conclusion_result = FA_conclusion_result[:50]
        print('在{}事实集合下进行推理key={}, while_count02 = {}, conclusion_result={}, Conclusion_Reasoning_Context={}'.format(TA_FA_Flag, rule_number, while_count02, FA_conclusion_result, FA_Conclusion_Reasoning_Context))
        if FA_conclusion_result[:30].find('output is') == -1:
            FA_conclusion_result = 'The output is:' + FA_conclusion_result
        if 'None' in FA_conclusion_result or 'none' in FA_conclusion_result and while_count02 > 3:
            reasoning_result = 'None'
            break
        if 'None' not in FA_conclusion_result and 'none' not in FA_conclusion_result and ':' in FA_conclusion_result and 'output' in FA_conclusion_result:
            FA_conclusion_result = FA_conclusion_result.replace('\n', '')
            FA_conclusion01 = re.findall(Output_Pattern, FA_conclusion_result)
            FA_conclusion01_string = FA_conclusion01[-1] if len(FA_conclusion01) > 0 else 'None'
            FA_conclusion01_list = FA_conclusion01_string.split('.')
            for key in range(len(FA_conclusion01_list)):
                if len(FA_conclusion01_list[key]) < 10 or len(FA_conclusion01_list[key]) > 40:
                    continue
                FA_conclusion02 = FA_conclusion01_list[key] + '. '
                reasoning_result = FA_conclusion02.replace('"', '')
                # FA_conclusion_list.append(FA_conclusion02)
                # # 如果某个约间规则推出了结论， 则需要将该结论加入到事实中。
                # FA_List_String02 = FA_List_String02 + FA_conclusion02
            break
        else:
            while_count02 = while_count02 + 1
            continue

    return reasoning_result

# 定义一个函数，直接调用大模型进行约简
def Iterative_Reduction_and_Reasoning_Prompt_Based_LLMs(TA_Fact_Lists,FA_Fact_Lists, TA_conclusion_list, FA_conclusion_list, Rule_string, Rule_key):
    TA_Fact_Lists02, FA_Fact_Lists02= copy.deepcopy(TA_Fact_Lists), copy.deepcopy(FA_Fact_Lists)
    # 在迭代遍历规则进行约简和推理时，需要将之前规则推出的结论对上下界进行更新
    if len(TA_conclusion_list) > 0:
        for key01 in range(len(TA_conclusion_list)):
            TA_Fact_Lists02.append(TA_conclusion_list[key01])
    if len(FA_conclusion_list) > 0:
        for key02 in range(len(FA_conclusion_list)):
            FA_Fact_Lists02.append(FA_conclusion_list[key02])

    TA_Fact_List_String02, FA_Fact_List_String02 = '',''
    for key01 in range(len(TA_Fact_Lists02)):
        TA_Fact_List_String02 = TA_Fact_List_String02 + TA_Fact_Lists02[key01]
    for key01 in range(len(FA_Fact_Lists02)):
        FA_Fact_List_String02 = FA_Fact_List_String02 + FA_Fact_Lists02[key01]

    TA_rule_reduction_result, FA_rule_reduction_result = '',''
    while_count = 1
    while True:
        while_count = while_count + 1
        TA_reduction_context = 'The facts are: ' + TA_Fact_List_String02 + 'The rule is: ' + Rule_string
        TA_reduction_result = Iterative_Base_Model(Iterative_Reduction_Prompt, TA_reduction_context)
        TA_reduction_result = TA_reduction_result.replace('\n', '')
        print('在TA事实集合下进行约简: rule_key = {}, while_count={}, TA_reduction_result={}, TA_reduction_context={}'.format(Rule_key, while_count, TA_reduction_result, TA_reduction_context))
        if ':' in TA_reduction_result and 'output' in TA_reduction_result:
            TA_reduction_rule = re.findall(Output_Pattern, TA_reduction_result)
            TA_reduction_rule_string = TA_reduction_rule[0]
            if 'Inconsistent' in TA_reduction_rule_string or 'inconsistent' in TA_reduction_rule_string:
                TA_rule_reduction_result = 'inconsistent'
                break
            TA_reduction_rule_string = TA_reduction_rule_string[1:] if TA_reduction_rule_string[0] == ' ' else TA_reduction_rule_string
            if len(TA_reduction_rule_string) < 10:
                break
            else:
                TA_rule_reduction_result= TA_reduction_rule_string
                break
        else:
            continue

    while_count = 1
    while True:
        while_count = while_count + 1
        FA_reduction_context = 'The facts are: ' + FA_Fact_List_String02 + 'The rule is: ' + Rule_string
        FA_reduction_result = Iterative_Base_Model(Iterative_Reduction_Prompt, FA_reduction_context)
        FA_reduction_result = FA_reduction_result.replace('\n', '')
        print('在TA事实集合下进行约简: rule_key = {}, while_count={}, TA_reduction_result={}, TA_reduction_context={}'.format(Rule_key, while_count, FA_reduction_result, FA_reduction_context))
        if ':' in FA_reduction_result and 'output' in FA_reduction_result:
            FA_reduction_rule = re.findall(Output_Pattern, FA_reduction_result)
            FA_reduction_rule_string = FA_reduction_rule[0]
            if 'Inconsistent' in FA_reduction_rule_string or 'inconsistent' in FA_reduction_rule_string:
                FA_rule_reduction_result = 'inconsistent'
                break
            FA_reduction_rule_string = FA_reduction_rule_string[1:] if FA_reduction_rule_string[0] == ' ' else FA_reduction_rule_string
            if len(FA_reduction_rule_string) < 10:
                break
            else:
                FA_rule_reduction_result = FA_reduction_rule_string
                break
        else:
            continue

    # 然后迭代的对约间结果进行推理
    # 推理步骤进一步分为二步，第一步进行约间，第二步进行推理Concluson操作推理
    if 'Inconsistent' not in FA_rule_reduction_result:
        TA_FA_Flag = 'FA'  # 用于指示是在下界还是上界进行推理
        FA_conclusion02 = Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, FA_Fact_List_String02, FA_rule_reduction_result,Rule_key)
    else:
        FA_conclusion02 = 'None'

    if 'Inconsistent' not in TA_rule_reduction_result:
        TA_FA_Flag = 'TA'  # 用于指示是在下界还是上界进行推理
        TA_conclusion02 = Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, TA_Fact_List_String02, TA_rule_reduction_result,Rule_key)
    else:
        TA_conclusion02 = 'None'

    print('Reduction and Reasoning: rule_number={},FA_Reduction_Result={}, FA_conclusion02={}, TA_Reduction_Result={}, TA_conclusion02={}'.format(Rule_key, FA_rule_reduction_result, FA_conclusion02, TA_rule_reduction_result, TA_conclusion02))

    return TA_conclusion02, FA_conclusion02

# 定义一个调用大模型进行选择下一个事实的函数
def choose_fact_Based_LLMs(fact_list01, fact_list02, Origin_Question_Text_Lists):
    TA_fact_string01, FA_fact_string01 = '', ''
    for key in range(len(fact_list01)):
        fact01 = fact_list01[key] + '. '
        fact01 = fact01.replace('\'', '').replace('..', '. ').replace('. .', '. ')
        TA_fact_string01 = TA_fact_string01 + fact01
    for key in range(len(fact_list02)):
        fact02 = fact_list02[key] + '. '
        fact02 = fact02.replace('\'', '').replace('..', '. ').replace('. .', '. ')
        FA_fact_string01 = FA_fact_string01 + fact02
    Question_Text_String = ''
    for question_key in range(len(Origin_Question_Text_Lists)):
        question_text = Origin_Question_Text_Lists[question_key]
        neg_question_text = question_text.replace(' is not ',' is ') if ' not ' in question_text else question_text.replace(' is ', ' is not ')
        Question_Text_String = Question_Text_String + question_text
        Question_Text_String = Question_Text_String + neg_question_text

    # 调用大模型随机从FA事实列表中选择一个添加到TA中
    # 设置一定的启发式函数，尽量选择跟问题、问题的非相似性最大的事实
    # 即要求选择在事实集合2中却不在事实集合1中，并且跟问题、问题的非相似性最大的事实加入。
    choose_context = 'The facts set 1 are: ' + TA_fact_string01 + 'The facts set 2 are: ' + FA_fact_string01 + ' The question are: ' + Question_Text_String
    choose_fact_result_string = ''
    while True:
        choose_fact_result = Iterative_Base_Model(Choose_fact_Prompt, choose_context)
        choose_fact_result = choose_fact_result.replace('\n', '')
        print('choose_fact_result={}, choose_context={}'.format(choose_fact_result, choose_context))
        # 如果不能选出事实

        if 'output' not in choose_fact_result or ':' not in choose_fact_result:
            continue
        elif 'output' in choose_fact_result and ':' in choose_fact_result:
            choose_fact_result = choose_fact_result.replace('\n', '')
            choose_fact_result = re.findall(Output_Pattern, choose_fact_result)
            choose_fact_string = choose_fact_result[0]
            if 'None' in choose_fact_string or 'none' in choose_fact_string:
                choose_fact_result_string = 'None'
                break
            if len(choose_fact_string) < 5:
                continue
            else:
                choose_fact_result_string = choose_fact_string
                break
    return choose_fact_result_string

# # 定义一个函数用于从事实集合二种选择一个不在事实集合1中的事实
def choose_fact_Based_Similarity(fact_list01, fact_list02, Origin_Question_Text_Lists):
    # 返回一个在集合2中但是不在集合1中的事实
    # 遍历集合2中事实与集合1中相似性最小那个事实
    fact_similarity = similarity(fact_list02, fact_list01)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    # 第一步根据相似度找出在事实集合2中但是不在事实集合1中的事实
    Remain_Fact_Lists = [] # 用于存储在事实集合2中但是不在事实集合1中的事实集合
    for key01 in range(len(fact_list02)):
        fact02 = fact_list02[key01]
        fact_similarity = max_fact_similarity01.values[key01]
        if fact_similarity < Similarity_Value:
            Remain_Fact_Lists.append(fact02)

    choose_fact = ''
    if len(Remain_Fact_Lists)>0:
        # 第二步 从剩余的事实中选择跟问题相似性最大那个事实
        # 获取问题和问题非的列表事实集合
        All_Question_Lists = []
        for question_Key in range(len(Origin_Question_Text_Lists)):
            All_Question_Lists.append(Origin_Question_Text_Lists[question_Key])
            question_neg = Origin_Question_Text_Lists[question_Key].replace('is not ',' is ') if ' not ' in Origin_Question_Text_Lists[question_Key] else Origin_Question_Text_Lists[question_Key].replace(' is ',' is not ')
            All_Question_Lists.append(question_neg)
        remain_fact_question_similarity = similarity(Remain_Fact_Lists, All_Question_Lists)
        # 计算出剩余事实中跟问题的最大匹配度
        max_fact_question_similarity01 = torch.max(remain_fact_question_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
        fact_question_similarity = 0
        for key in range(len(Remain_Fact_Lists)):
            if max_fact_question_similarity01.values[key] > fact_question_similarity:
                fact_question_similarity = max_fact_question_similarity01.values[key]
                choose_fact = Remain_Fact_Lists[key]
            else:
                continue
    else:
        choose_fact = 'None'

    return choose_fact

# 根据生成的回答集利用相似性进行打标签
def Skeptical_Credulous_Reasoning_based_Similarity(NL_Origin_Facts, NL_Origin_Question_Text):

    global Answer_Set_List, Soft_Answer_Set_List
    Similarity_Value = 0.85
    # 如果Answer_Set_List为空，但是soft_Answer_Set_List不为空， 则将Soft_Answer_Set_List赋值给Answer_Set_List
    Answer_Set_List = copy.deepcopy(Answer_Set_List) if len(Answer_Set_List)!=0 else copy.deepcopy(Soft_Answer_Set_List)
    print('NL_Origin_Question_Text:={}, Answer_Set_List ={}'.format(NL_Origin_Question_Text, Answer_Set_List))
    Explain_Set_Fact_Dict = {} # 用于存储预测问题标签的解释，关键字为问题的序号【1、2、3】，值为解释
    # 去除答案集中的事实，只保留回答集中的结论事实
    facts_list01 = NL_Origin_Facts.split('.')
    Fact_List = []
    for fact_Key01 in range(len(facts_list01)):
        if len(facts_list01[fact_Key01]) < 5:
            continue
        else:
            fact_string = facts_list01[fact_Key01] + '.'
            Fact_List.append(fact_string)

    Question_Label = ''
    neg_question_fact = ''
    Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List= [], []

    for question_key in range(len(NL_Origin_Question_Text)):
        if question_key not in Explain_Set_Fact_Dict.keys():
            Explain_Set_Fact_Dict[question_key] = {}
        question_fact = NL_Origin_Question_Text[question_key]
        if 'not' in question_fact:
            neg_question_fact = question_fact.replace(' not ',' ')
        else:
            if ' is ' in question_fact:
                neg_question_fact = question_fact.replace(' is ', ' is not ')
            elif ' does ' in question_fact:
                neg_question_fact = question_fact.replace(' does ', ' does not ')
            elif ' do ' in question_fact:
                neg_question_fact = question_fact.replace(' do ', ' do not ')
            elif ' may be ' in question_fact:
                neg_question_fact = question_fact.replace(' may be ', ' may not be')
            elif ' can ' in question_fact:
                neg_question_fact = question_fact.replace(' can ', ' can not ')
            elif ' might be ' in question_fact:
                neg_question_fact = question_fact.replace(' might be ', ' might not be')
            elif ' appears ' in question_fact:
                neg_question_fact = question_fact.replace(' appears ', ' does not appears ')
            elif ' remains ' in question_fact:
                neg_question_fact = question_fact.replace(' remains ', ' does not remains ')
            elif ' maintains ' in question_fact:
                neg_question_fact = question_fact.replace(' maintains ', ' does not maintains ')
            elif ' lacks ' in question_fact:
                neg_question_fact = question_fact.replace(' lacks ', ' does not lacks ')
            elif ' exhibits ' in question_fact:
                neg_question_fact = question_fact.replace(' exhibits ', ' does not exhibits ')
            elif ' tends ' in question_fact:
                neg_question_fact = question_fact.replace(' tends ', ' does not tends ')


        Answer_set_List02 = copy.deepcopy(Answer_Set_List)
        question_answer_label=[]
        negquestion_answer_label = []
        Skeptical_Explan_q_list =[]
        Skeptical_Explan_neg_q_list = []
        Skeptical_Explan_none_q_list = []
        Credulous_Explan_q_list = []
        Credulous_Explan_neg_q_list = []
        Credulous_Explan_none_q_list = []
        if Reasoning_Mode =='skeptical':
            for answer_key in range(len(Answer_Set_List)):
                # 获取去除事实集合中的结论事实
                Explain_fact_list = Remove_Fact(Fact_List, Answer_Set_List[answer_key])

                # 计算问题与回答集合中的事实的相似性
                question_answer_similarity = similarity([question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_question_answer_similarity01 = torch.max(question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                # 计算问题否定与回答集合中的事实的相似性
                neg_question_answer_similarity = similarity([neg_question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_neg_question_answer_similarity01 = torch.max(neg_question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                if max_question_answer_similarity01.values >= Similarity_Value:
                    question_answer_label.append('True')
                    Skeptical_Explan_q_list.append(Explain_fact_list)
                else:
                    question_answer_label.append('False')
                if max_neg_question_answer_similarity01.values >= Similarity_Value:
                    negquestion_answer_label.append('True')
                    Skeptical_Explan_neg_q_list.append(Explain_fact_list)
                else:
                    negquestion_answer_label.append('False')
                if max_question_answer_similarity01.values < Similarity_Value or max_neg_question_answer_similarity01.values < Similarity_Value:
                    Skeptical_Explan_none_q_list.append(Explain_fact_list)
            # 如果问题原子相似性匹配结果中不存在False,则说明都是True; 问题原子非的相似性匹配结果中不存在True, 则说明该问题可以在可怀疑推理模式下为True.
            if 'False' not in question_answer_label and 'True' not in negquestion_answer_label:
                Question_Label = 'T'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_q_list
            elif 'True' not in question_answer_label and 'False' not in negquestion_answer_label:
                Question_Label = 'F'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_neg_q_list
            elif 'False' in question_answer_label and 'False' in negquestion_answer_label:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_none_q_list
            else:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_none_q_list

        elif Reasoning_Mode == 'credulous':

            for answer_key in range(len(Answer_Set_List)):
                # 获取去除事实集合中的结论事实
                Explain_fact_list = Remove_Fact(Fact_List, Answer_Set_List[answer_key])
                # 计算问题与回答集合中的事实的相似性
                question_answer_similarity = similarity([question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_question_answer_similarity01 = torch.max(question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                # 计算问题否定与回答集合中的事实的相似性
                neg_question_answer_similarity = similarity([neg_question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_neg_question_answer_similarity01 = torch.max(neg_question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                if max_question_answer_similarity01.values >= Similarity_Value:
                    question_answer_label.append('True')
                    Credulous_Explan_q_list.append(Explain_fact_list)
                else:
                    question_answer_label.append('False')
                if max_neg_question_answer_similarity01.values >= Similarity_Value:
                    negquestion_answer_label.append('True')
                    Credulous_Explan_neg_q_list.append(Explain_fact_list)
                else:
                    negquestion_answer_label.append('False')
                if max_question_answer_similarity01.values < Similarity_Value and max_neg_question_answer_similarity01.values < Similarity_Value:
                    Credulous_Explan_none_q_list.append(Explain_fact_list)


            if 'True' in question_answer_label:
                Question_Label = 'T'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_q_list
            elif 'True' in negquestion_answer_label:
                Question_Label = 'F'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_neg_q_list
            elif 'True' not in question_answer_label and 'True' not in negquestion_answer_label:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_none_q_list
            else:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_none_q_list

        # 对生成的结果进行分析
        Skeptical_LLMs_Generted_Label_List.append([Question_Label])
        Credulous_LLMs_Generted_Label_List.append([Question_Label])

    return Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List, Explain_Set_Fact_Dict

# 定义一个函数，用于基于大模型对问题在生成的回答集上进行打标签
def Skeptical_Credulous_Reasoning_based_LLMs( NL_Origin_Question_Text):

    # 可能存在多个回答集，将每个回答集转换成字符串的形式。
    global Answer_Set_List, Soft_Answer_Set_List
    # 如果Answer_Set_List为空，但是soft_Answer_Set_List不为空， 则将Soft_Answer_Set_List赋值给Answer_Set_List
    Answer_Set_List = copy.deepcopy(Answer_Set_List) if len(Answer_Set_List)!=0 else copy.deepcopy(Soft_Answer_Set_List)
    Answer_Set_String_List = []
    for key01 in range(len(Answer_Set_List)):
        answer_set = Answer_Set_List[key01]
        answer_set_string = ''
        for key02 in range(len(answer_set)):
            answer_set_string = answer_set_string + answer_set[key02]
        Answer_Set_String_List.append(answer_set_string)

    # 遍历Answer_Set_String_List，构建提示内容
    answer_set_string_prompt = ''
    for key03 in range(len(Answer_Set_String_List)):
        answer_set_string_prompt = answer_set_string_prompt + 'The extension ' + str(int(key03)+1) + ' are: ' + Answer_Set_String_List[key03]
    Reasoning_Instruction= ''
    if Reasoning_Mode == 'Skeptical':
        Reasoning_Instruction = Skeptical_Reasoning_Prompt
    else:
        Reasoning_Instruction = Credulous_Reasoning_Prompt


    Question_Text_String = ''
    Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List= [], []
    for question_key in range(len(NL_Origin_Question_Text)):
        question_text = ' The question is: ' + NL_Origin_Question_Text[question_key]
        Question_Text_String = question_text
        answer_set_string_prompt01 = answer_set_string_prompt + Question_Text_String
        # 调用大模型预测
        question_answer_result = ''
        while True:
            skeptical_question_answer_result = Iterative_Base_Model(Skeptical_Reasoning_Prompt, answer_set_string_prompt01)
            if len(skeptical_question_answer_result) < 4:
                continue
        ### 添加一个函数用于对大模型生成结果的格式进行判断，如何不符合格式，则重新生成。
            if 'unknown' not in skeptical_question_answer_result and 'Unknown' not in skeptical_question_answer_result and 'true' not in skeptical_question_answer_result and 'True' not in skeptical_question_answer_result and 'false' not in skeptical_question_answer_result and 'False' not in skeptical_question_answer_result:
                continue
            else:
                break
        skeptical_predict_label = None
        if 'unknown' in skeptical_question_answer_result or 'Unknown' in skeptical_question_answer_result:
            skeptical_predict_label = 'M'
        elif 'true' in skeptical_question_answer_result or 'True' in skeptical_question_answer_result:
            skeptical_predict_label = 'T'
        elif 'false' in skeptical_question_answer_result or 'False' in skeptical_question_answer_result:
            skeptical_predict_label = 'F'
        else:
            skeptical_predict_label = 'M'
        print('question_text:{}, skeptical_question_answer_result:{}, Answer_Set_List:{}'.format(question_text, skeptical_question_answer_result, Answer_Set_List))


        # while True:
        #     credulous_question_answer_result = Iterative_Base_Model(Credulous_Reasoning_Prompt, answer_set_string_prompt01)
        #     if len(credulous_question_answer_result)<4:
        #         continue
        # ### 添加一个函数用于对大模型生成结果的格式进行判断，如何不符合格式，则重新生成。
        #     if 'unknown' not in credulous_question_answer_result and 'Unknown' not in credulous_question_answer_result and 'true' not in credulous_question_answer_result and 'True' not in credulous_question_answer_result and 'false' not in credulous_question_answer_result and 'False' not in credulous_question_answer_result:
        #         continue
        #     else:
        #         break
        # credulous_predict_label = None
        # if 'unknown' in credulous_question_answer_result or 'Unknown' in credulous_question_answer_result:
        #     credulous_predict_label = 'M'
        # elif 'true' in credulous_question_answer_result or 'True' in credulous_question_answer_result:
        #     credulous_predict_label = 'T'
        # elif 'false' in credulous_question_answer_result or 'False' in credulous_question_answer_result:
        #     credulous_predict_label = 'F'
        # else:
        #     credulous_predict_label = 'M'

        # 对生成的结果进行分析
        Skeptical_LLMs_Generted_Label_List.append([skeptical_predict_label])
        Credulous_LLMs_Generted_Label_List.append([skeptical_predict_label])

    return Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List, Answer_Set_String_List

# 定义扩展函数expand
def Expand_p(Fact_List01, TA_List, FA_List, Rule_List01):

    TA_List01, FA_List01 = copy.deepcopy(TA_List), copy.deepcopy(FA_List)
    global Prerequisite_Conclusion_Consistent_Facts_Dict
    while_count01 = 0
    while True:
        TA_List02 , FA_List02 = copy.deepcopy(TA_List01), copy.deepcopy(FA_List01)
        # 遍历所有规则，通过正结论推理神经网络模块Cn(P^{FA})和负结论神经网络推理模块
        # 调用大模型来判断是根据下界事实集合是否能够将规则中的结论加入回答集下界集合中，、
        # 调用大模型去实现Cn(P^{FA})，即正结论推理神经网络模块，如果在FA_List事实列表下能推出结论，则将该结论事实加入TA中， L<- L' U Cn(P^{FA})
        # 调用大模型去实现Cn(P^{TA}),即负结论推理神经网络模块， U <- U' /\ Cn(P^TA)
        # 将事实列表转换成事实字符串


        TA_conclusion_list, FA_conclusion_list = [], [] # U原子上程序的结论集合
        TA_conclusion, FA_conclusion = 'None', 'None' # U原子上程序的结论集合
        rule_string = ''
        for rule_key in range(len(Rule_List01)): # 获取所有的规则字符串
            rule_string = rule_string + Rule_List01[rule_key] + '. '
        # 推理步骤进一步分为二步，第一步进行约间，第二步进行
        # 调用大模型分别实现在TA和FA事实下对程序规则进行约减
        # TA_Reduction_Rule_List存储的是在TA原子约减产生的规则集合。 FA_Reduction_Rule_List存储的是在FA原子约减后产生的规则集合
        TA_Reduction_Rule_List, FA_Reduction_Rule_List = [],[] #用于存储约减之后的规则列表
        Rule_String = ''
        for rule_key in range(len(Rule_List01)):
            rule_number = int(rule_key)
            Rule_String = Rule_List01[rule_key] + '. '
            while_count = 1
            reduction_rule = 'The rule is: ' + Rule_String
            # 基于相似性计算下界和上界下的约简
            TA_conclusion02, FA_conclusion02 = Iterative_Split_Reduction_Prompt_Based_Similarity(TA_List02, FA_List02, TA_conclusion, FA_conclusion, reduction_rule, rule_number)

            if 'None' not in TA_conclusion02 and len(TA_conclusion02)>10:
                TA_conclusion_list.append(TA_conclusion02)
                TA_conclusion = TA_conclusion02
                # TA_List02 = fact_union(TA_List02, [TA_conclusion02]) if len(TA_conclusion02) != 0 else TA_List02

            if 'None' not in FA_conclusion02 and len(FA_conclusion02)>10:
                FA_conclusion_list.append(FA_conclusion02)
                FA_conclusion = FA_conclusion02
                # FA_List02 = fact_union(FA_List02, [FA_conclusion02]) if len(FA_List02) != 0 else FA_List02

        print('一轮迭代产生的结论事实集合：TA_conclusion_list={}, FA_conclusion_list={}'.format(TA_conclusion_list, FA_conclusion_list))
        # FA_conclusion_list表示的是P^U', 需要将所有事实加入P^U'中，U' =FA_List02 然后再做处理。
        TA_List01 = fact_union(TA_List02, FA_conclusion_list) if len(FA_conclusion_list)!=0 else TA_List02
        TA_List01 = Remove_Same_Fact(TA_List01)
        print('TA U P^U={}, len(TA_List02)={}, len(FA_conclusion_list)= {}'.format(len(TA_List01), len(TA_List02), len(FA_conclusion_list)))
        # TA_conclusion_list表示的是P^L', 需要将所有事实加入P^L‘中，L‘ = TA_List02然后再做处理。
        # TA_conclusion_list= fact_union(TA_conclusion_list, Fact_List01) # TA_conclusion_list表示的是P^L', 需要将所有事实加入P^L‘中，然后再做处理。, 这里先交，在将事实添加进去。
        # 调用求交函数进行交操作
        if while_count01 == 0:
            Facts_TA_conclusion_list = fact_union(Fact_List01, TA_conclusion_list) if len(TA_conclusion_list)!=0 else Fact_List01 # 将下界集合产生的结论事实与原始事实合并
            FA_List03 = fact_intersection(FA_List02, Facts_TA_conclusion_list) # 在于上界事实集合求交
            FA_List01 = FA_List03 # 将U'赋值给U
        else:
            Facts_TA_conclusion_list = fact_union(Fact_List01, TA_conclusion_list) if len(TA_conclusion_list)!=0 else Fact_List01# 将下界集合产生的结论事实与原始事实合并
            FA_List03 = fact_intersection(FA_List, Facts_TA_conclusion_list) # 在于上界事实集合求交
            FA_List01 = fact_union(FA_List01, FA_List03) if len(FA_List03)!=0 else FA_List01# 将这轮的U'与Cn（P^L'）的交结果与上一轮的结果事实合并。

        print('FA 交 P^L={}, len(FA_List02)={}, len(TA_conclusion_list)= {}'.format(len(FA_List01), len(FA_List02), len(TA_conclusion_list)))

        # U'与Cn（P^L'）的交之后，需要再添加和事实合并。
        # 调用大模型将U'与Cn（P^L'）交的结果再跟事实合并
        # 调用并函数进行并操作
        # 需要先将TA_conclusion_list与事实合并之后再跟FA_List02求并集
        # Facts_TA_conclusion_list = fact_union(Fact_List01, TA_conclusion_list)
        # FA_List01 = fact_intersection(FA_List02, Facts_TA_conclusion_list)
        # FA_List01 = fact_union(FA_List01, TA_conclusion_list)
        # print('FA 交 P^L={}, len(FA_List02)={}, len(Facts_TA_conclusion_list)={}, len(TA_conclusion_list)= {}'.format(len(FA_List01), len(FA_List02), len(Facts_TA_conclusion_list), len(TA_conclusion_list)))

        # 判断L跟L‘是否相等
        equal_result01 = equation(TA_List01, TA_List02)
        print("equal_result01={}, TA_List01={}, TA_List02={}".format(equal_result01, TA_List01, TA_List02))
        # 判断U跟U‘是否相等
        equal_result02 = equation(FA_List01, FA_List02) # 判断L与U是否等价
        print('equal_result02={}, FA_List01={},FA_List02 ={} '.format(equal_result02,FA_List01, FA_List02))
        # 应该是循环结束后，当L和U稳定之后再判断L是否是U的子集
        subset_result03, different_fact_number = Include(TA_List01, FA_List01) # 判断L是否是U的子集
        print("subset_result03={}, TA_List01={}, FA_List01={}".format(subset_result03, TA_List01, FA_List01))

        if while_count01 >= 2:
            if "False" in subset_result03 or 'false' in subset_result03 : # L不属于U
                print('while_count01 ={} ,TA_List01={}, FA_List01={}'.format(while_count01, TA_List01, FA_List01))
                print('下界L不属于U, 退出下界和上界迭代循环！')
                break
        if "True" in equal_result01 and "True" in equal_result02: # 如果上界和下界都没有发生变化，则推出循环 ( L/TA_List01= L'/TA_List02  and U/FA_List01= U'/FA_List02)
            print('while_count01={}, 下界和上界稳定， 退出下界和上界迭代循环。 回答集迭代扩展完成，Expand Successfully!'.format(while_count01))
            break

        # if len(TA_List01) >= len(FA_List01): # 如果下界大于等于上界，则退出循环
        #     print('下界TA_List01={}高于上界FA_List01={}，退出循环！'.format(len(TA_List01), len(FA_List01)))
        #     break
        while_count01 = while_count01 + 1
        if while_count01 >= 8:
            print('下界和上界迭代次数超过4次while_count01={}，退出循环！'.format(while_count01))
            break

    return TA_List01, FA_List01, subset_result03, different_fact_number

# 调用Solve_P函数求解所有回答集
def Slove_P(Fact_List, TA_List, FA_List, Rule_List01,slove_iternumber, NL_Origin_Question_Text):
    global Answer_Set_List, Soft_Answer_Set_List, Each_Example_chatgpt_Number

    print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List), len(Soft_Answer_Set_List)))

    if len(TA_List)-len(FA_List)<=1 and len(TA_List)>=len(FA_List): # 如果下界和上界相差小于2，则直接返回下界作为回答集
        Soft_Answer_Set_List.append(TA_List)
        print("下界TA_List={}高于上界FA_List={}，将回答集加入Soft_Answer_Set_List中，不需要进一步推理。".format(len(TA_List), len(FA_List)))
        print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List),len(Soft_Answer_Set_List)))
    elif len(Answer_Set_List) + len(Soft_Answer_Set_List) >= 5:
        print('回答集数量超过5个，跳出循环！')
    else:
        Fact_List01 = copy.deepcopy(Fact_List)
        TA_List01, FA_List01, Include_subset_flag, different_fact_number = Expand_p(Fact_List01, TA_List, FA_List, Rule_List01)
        slove_iternumber = slove_iternumber + 1
        print('slove_iternumber={}'.format(slove_iternumber))

        subset_result01 = Include_subset_flag # Include(TA_List01, FA_List01)
        equal_result01 = equation(TA_List01, FA_List01)
        if "True" in equal_result01 and 'True' in subset_result01:  # 如果说明找到了一个回答集
            Answer_Set_List.append(TA_List01)
            print('搜索成功，找到了一个回答集TA_List01 = {}, len(Answer_Set_List)={}, Answer_Set_List={}'.format(TA_List01, len(Answer_Set_List), Answer_Set_List))
            print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List),len(Soft_Answer_Set_List)))
        elif len(TA_List01) >= len(FA_List01):  # 如果下界大于等于上界，相差小于2，则直接返回上界作为回答集
            Soft_Answer_Set_List.append(TA_List01)
            print("下界TA_List={}高于上界FA_List={}，将回答集加入Soft_Answer_Set_List中，不需要进一步推理。".format(len(TA_List01), len(FA_List01)))
            print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List), len(Soft_Answer_Set_List)))
        elif "False" in subset_result01 and different_fact_number >=2:  # L不属于U 说明搜搜失败，返回目前的回答集
            if len(Answer_Set_List)==0 and len(Soft_Answer_Set_List)==0:
                Soft_Answer_Set_List.append(TA_List01)
                print("L不属于U,搜索失败")
                print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List),len(Soft_Answer_Set_List)))
            else:
                print("L不属于U,搜索失败")
                print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List),len(Soft_Answer_Set_List)))

        else: # 否则从U中添加一个到L中
            # 遍历u,找出不在L中得事实集合, 应该要求选择的事实属于规则的结论。 ， 需要定制策略来选择合适的事实
            print('随机从可能事实中添加一个到回答集中！')
            # 第一种选择方法：基于大模型的进行选择下一个事实加入到下界中。
            # 随机从Other_Lists中选择一个事实添加到TA_List01
            #choose_fact_string = choose_fact_Based_LLMs(TA_List01, FA_List01, NL_Origin_Question_Text)

            # 第二种： 基于相似度计算的选择事实的方法
            choose_fact_string = choose_fact_Based_Similarity(TA_List01, FA_List01, NL_Origin_Question_Text)
            print('choose_fact_string={}'.format(choose_fact_string))
            choose_None = True if 'None' not in choose_fact_string else False

            if choose_None == True:
                TA_List02 = copy.deepcopy(TA_List01)
                TA_List02.append(choose_fact_string)
                slove_iternumber01=0
                Slove_P(Fact_List01, TA_List02, FA_List01, Rule_List01, slove_iternumber01, NL_Origin_Question_Text)
                FA_List03 = copy.deepcopy(FA_List01)
                FA_List04 = Remove(choose_fact_string, FA_List03)
                print("删除事实choose_fact_string={}, 删除前FA_List03={}， 删除后FA_List04={}".format(choose_fact_string,FA_List03, FA_List04))
                slove_iternumber02 = 0
                Slove_P(Fact_List01, TA_List01, FA_List04, Rule_List01, slove_iternumber02, NL_Origin_Question_Text)
            else: # U/L中没有选出新的事实
                Answer_Set_List.append(TA_List01)
                print('由于U\L中不再有额外的事实，将此时的下界作为回答集TA_List01 = {}, len(Answer_Set_List)={}, Answer_Set_List={}'.format(TA_List01,len(Answer_Set_List), Answer_Set_List))


# 调用神经符号求解器，输入为事实和规则结合，输出为所有的回答集，然后根据输出的回答集来回答问题。
def NeSy_NMR_Solver(NL_Origin_Facts, NL_Defalut_Rules, NL_Origin_Question_Text):
    TA_List = [] # 用于存储回答集的下限，
    FA_List = [] # 用于存储回答集的上限
    Facts_List = []
    # 初始化回答集的上限和下限
    # 初始化回答集下限
    facts_list01 = NL_Origin_Facts.split('.')
    for fact_Key01 in range(len(facts_list01)):
        if len(facts_list01[fact_Key01])<5:
            continue
        else:
            fact_string = facts_list01[fact_Key01] + '.'
            TA_List.append(fact_string)
            Facts_List.append(fact_string)
    # 初始化回答集上限
    Grounded_Rule_List01 = [] # 存储所有实例化后的规则的列表
    rules_lists01 = NL_Defalut_Rules.split('.')
    Total_Rule_Strings = ''
    for rule_key01 in range(len(rules_lists01)): # 遍历每一个规则，对所有规则进行实例化。
        if len(rules_lists01[rule_key01])<5:
            continue
        else:
            Total_Rule_Strings = rules_lists01[rule_key01] + '. '
            pass
        # 调用大模型对每个规则进行实例化，一次性实例化出所有的
        grounded_rule_result = Grounded_Reasoning_based_LLMs(NL_Origin_Facts, Total_Rule_Strings, rule_key01)
        Grounded_Rule_List01.append(grounded_rule_result)

    # 遍历所有的规则，然后调用大模型获取规则中实例化后的结论
    fact01 = TA_List[0]
    FA_List = []  # 用于存储回答集的上限
    for rule_key02 in range(len(Grounded_Rule_List01)):
        rule_string01 = Grounded_Rule_List01[rule_key02]
        Grounded_conclusion_Context =  'The input rule is:' + rule_string01 + '.'
        Grounded_conclusion_Context = Grounded_conclusion_Context.replace('..','.').replace('  ',' ')
        grounded_conclusion_result = ''

        while_count01 =0
        Last_FA_List = [] #多次训练，求最佳的FA集合
        while True:
            result = Iterative_Base_Model(All_Atomes_Prompt_Instruction, Grounded_conclusion_Context)
            result = result.replace('\n','')
            if result.find('###') == -1:
                result = result + '###'
            if result.find('The output is:') == -1:
                while_count01 = while_count01 + 1
                continue
            grounded_conclusion_result_string = ''
            grounded_conclusion_result_list = []
            while_count01 = while_count01 + 1
            if while_count01 > 10:
                break
            print('rule_key02={}, while_count01={}, result={}, Grounded_conclusion_Context={}'.format(rule_key02, while_count01, result, Grounded_conclusion_Context))
            if ':' in result and 'output' in result:
                grounded_conclusion_result_string = re.findall(Output_Pattern, result)
                print(grounded_conclusion_result_string)
                if len(grounded_conclusion_result_string) == 0:
                    while_count01 = while_count01 + 1
                    continue
                result = grounded_conclusion_result_string[-1]
                if len(result) < 10:
                    while_count01 = while_count01 + 1
                    continue
                grounded_conclusion_result_list = []
                grounded_conclusion_result_list01 = result.split('.')
                for grounded_fact_Key in range(len(grounded_conclusion_result_list01)):
                    if len(grounded_conclusion_result_list01[grounded_fact_Key])<5:
                        continue
                    else:
                        grounded_fact01 = grounded_conclusion_result_list01[grounded_fact_Key]
                        grounded_fact01 = grounded_fact01.replace('\'', '').replace('  ', ' ').replace('..', '.').replace('-','')
                        grounded_conclusion_result_list.append(grounded_fact01)

                FA_List = [grounded_conclusion_result_list[0]+'.'] if len(FA_List)==0 else FA_List
                fact_similarity = similarity(grounded_conclusion_result_list, FA_List)
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                Max_Similarity_grounded_fact = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值

                for gounded_fact_key02 in range(len(grounded_conclusion_result_list)):
                    if Max_Similarity_grounded_fact.values[gounded_fact_key02]<Similarity_Value and len(grounded_conclusion_result_list[gounded_fact_key02]) > 3 and len(grounded_conclusion_result_list[gounded_fact_key02]) < 40:
                        grounded_fact = grounded_conclusion_result_list[gounded_fact_key02] + '. '
                        grounded_fact = grounded_fact.replace('\'','').replace('  ',' ').replace('..','.')
                        if grounded_fact[0] == ' ':
                            grounded_fact = grounded_fact[1:]
                        FA_List.append(grounded_fact)

                break
            else:
                while_count01 = while_count01 + 1
                continue
    # 去重
    FA_List = Remove_Same_Fact(FA_List)
    print('获取U事实集合的结果len(FA_List)={}, FA_List={}：'.format(len(FA_List), FA_List))
    # 然后调用函数Solve_p来计算所有得回答集。
    slove_iternumber = 0 # 用于限制深度搜索深度 大于等于3就停止搜索，将此时的下界作为回答集返回。
    print('最初的下界len(TA_List) = {}, 上界(FA_List) ={}, TA_List = {}, FA_List = {}'.format(len(TA_List), len(FA_List), TA_List, FA_List))
    Slove_P(Facts_List, TA_List, FA_List, Grounded_Rule_List01, slove_iternumber, NL_Origin_Question_Text)


def Read():
    with open(Read_Data_file, 'r', encoding='utf-8') as f0, open(Write_file_path02, 'a', encoding='utf-8') as f1:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict = {}
        Test_Extension_Example_Dict01 = {6: 0, 8: 0, 10: 0, 12: 0, 16: 0} if OOD_Flag == True else {2: 100, 1: 94, 4: 100, 3: 100, 5: 40} #  {2: 27, 1: 6, 4: 19, 3: 6, 5: 1}
        for line in f0:
            global Answer_Set_List, Soft_Answer_Set_List, Prerequisite_Conclusion_Consistent_Facts_Dict
            global Each_Example_chatgpt_Number
            Each_Example_chatgpt_Number = 0
            Write_Dict = {}  # 该字典用于存储需要写入的样本字典
            LLMs_Generted_Label_List = []
            LLMs_Generted_Answer_Set_Explanation_List = []
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            # print(json.dumps(js, ensure_ascii=False))
            Sample_number = js['Sample_number']
            Origin_Facts = js['Origin_Facts']
            Facts_number = js['Facts_number']  # 计算缺省理论中事实的个数
            Defalut_Rules = js['Defalut_Rules']
            # Noise_Facts_Lists = js['Noise_Facts_Lists']
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            # NL_Noise_Facts_Lists = js['NL_Noise_Facts_Lists']

            # Noise_Default_Rules_Lists = js['Noise_Default_Rules_Lists']
            # NL_Noise_Default_Rule_Lists = js['NL_Noise_Default_Rule_Lists']
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']
            Origin_Question_Text_Lists = js['Origin_Question_Text_Lists']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            Origin_Question_proof_List = js['Origin_Question_proof_List']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']

            # # 每个扩展数量的样本测试20个
            if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                    Total_count01 = Total_count01 + 1
                    continue
            else:
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] >= 100:
                    continue
                else:
                    Test_Extension_Example_Dict[Origin_ASP_extension_number] = Test_Extension_Example_Dict[Origin_ASP_extension_number] + 1
                    if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                        Total_count01 = Total_count01 + 1
                        continue

            Answer_Set_List, Soft_Answer_Set_List = [],[]
            Prerequisite_Conclusion_Consistent_Facts_Dict = copy.deepcopy({})
            if Total_count01 <= -1:
                Total_count01 = Total_count01 + 1
                print('Test_Extension_Example_Dict={}'.format(Test_Extension_Example_Dict))
                continue

            NeSy_NMR_Solver(NL_Origin_Facts, NL_Defalut_Rules, NL_Origin_Question_Text)

            # Answer_Set_List根据求出的回答集分别利用谨慎推理模式和可怀疑推理模式来回答问题
            # 调用函数基于神经符号方法的结果进行推理 分别使用大模型来进行可怀疑推理和谨慎推理。
            # Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List, Explain_Set_String_List = Skeptical_Credulous_Reasoning_based_Similarity(NL_Origin_Facts, NL_Origin_Question_Text)
            # print('Total_count01={}, True_Label_Lists = {}, Predict_Label_List={}'.format(Total_count01, Origin_Question_Label_Lists, Skeptical_LLMs_Generted_Label_List))

            Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List, Explain_Set_String_List = Skeptical_Credulous_Reasoning_based_LLMs( NL_Origin_Question_Text)
            print('Total_count01={}, True_Label_Lists = {}, Predict_Label_List={}'.format(Total_count01, Origin_Question_Label_Lists, Skeptical_LLMs_Generted_Label_List))


            Total_count01 = Total_count01 + 1

            Write_Dict['Sample_number'] = Sample_number  # 样本个数
            Write_Dict['Origin_ASP_extension_number'] = Origin_ASP_extension_number
            Write_Dict['NL_Origin_Question_Text'] = NL_Origin_Question_Text
            Write_Dict['Origin_Question_Label_Lists'] = Origin_Question_Label_Lists
            Write_Dict['LLMs_Generated_Question_Skeptical_Label_Lists'] = Skeptical_LLMs_Generted_Label_List
            Write_Dict['LLMs_Generated_Question_Credulous_Label_Lists'] = Credulous_LLMs_Generted_Label_List

            Write_Dict['Origin_Question_proof_List'] = Origin_Question_proof_List
            Write_Dict['NL_Origin_Question_proof_Text'] = NL_Origin_Question_proof_Text
            Write_Dict['LLMs_Generated_Question_Explanation_Lists'] = Explain_Set_String_List
            Write_Dict['Each_Example_chatgpt_Number'] = Each_Example_chatgpt_Number

            Write_Dict['LLMs_Repose'] = ''
            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')


        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List) # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List,average = 'macro')
        print('accuracy={},F1={}'.format(accuracy,F1))


if __name__ == '__main__':
    Read()
